<?php

use App\Http\Controllers\Admin\RiderController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\UserLoginController;
use App\Http\Controllers\UserRegisterController;
use App\Http\Controllers\Web\HomePageController;
use App\Models\Comments;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [HomePageController::class, 'index'])->name('home.index');
Route::resource('homepage', HomePageController::class);


Route::get('/mekanisme', function(){
    return view('web.mekanisme.index');
})->name('mekanisme');

Route::post('comment', [HomePageController::class,'comment'])->name('comment');
Route::resource('daftar', UserRegisterController::class);

Route::get('/google-sign-in', [UserLoginController::class, 'google'])->name('sign.google');
Route::get('/auth/google/callback', [UserLoginController::class, 'handleGoogleCallback']);


Auth::routes();


Route::group(['middleware' => 'auth'], function () {

    Route::get('/dashboard', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

    Route::resource('riders', RiderController::class);

    Route::get('data-table', [UserController::class,'table'])->name('table');
    Route::resource('users', UserController::class);

});
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
