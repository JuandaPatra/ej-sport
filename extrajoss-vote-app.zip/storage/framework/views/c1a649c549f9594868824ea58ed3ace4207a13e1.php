

<?php $__env->startSection('container'); ?>


<section id="banner-header">
    <div class="relative">
        <div class="banner-slider">
            <div class="relative ">
                <div class="absolute top-[230px] lg:top-[120px] left-0 right-0 text-white">
                </div>

                <picture>
                    <source media="(min-width:1000px)" srcset="<?php echo e(asset('images/banner-desktop.jpg')); ?>">
                    <source media="(min-width:320px)" srcset="<?php echo e(asset('images/banner-mobile.png')); ?>">
                    <img src="<?php echo e(asset('images/banner-desktop.jpg')); ?>" alt="Flowers" class=" w-full lg:h-[810px] object-cover">
                </picture>

            </div>
        </div>
        <nav class="fixed  z-30 w-100 top-0 left-0 bg-transparent px-10 sm:px-6 py-4 xl:px-[70px] lg:pt-[25px] h-[100px] navbar-top">
            <div class="container flex flex-wrap justify-between items-center mx-auto">
                <a href="" class="flex items-center">
                    <img src="<?php echo e(asset('images/logo.png')); ?>" class="absolute top-[8px] mr-3  h-[75px] lg:h-[150px]" alt="Extrajoss Logo">
                </a>

                <li class="lg:hidden flex items-center ml-[30%]">
                    <a href="https://extrajoss.co.id/pemenang" class="text-[#FF0000] leading-[20px] block pr-4 pl-3 font-head md:text-[18px] lg:text-[22px]" aria-current="page"><img src="<?php echo e(asset('images/logoejaudax.png')); ?>" class="h-[30px]" alt=""></a>
                </li>


                <a id="menu-hamburger" class="lg:hidden">
                    <div class="space-y-2">
                        <span class="block w-8 h-0.5 bg-gray-600"></span>
                        <span class="block w-8 h-0.5 bg-gray-600"></span>
                        <span class="block w-5 h-0.5 bg-gray-600"></span>
                    </div>
                </a>

               


                <div class=" w-full md:block md:w-auto pb-8 hidden lg:block" id="navbar-default">
                    <ul class="flex flex-col px- md:flex-row md:space-x-2 lg:space-x-4 md:mt-0 ">
                        <li class="flex items-center">
                            <a href="https://extrajoss.co.id" class="text-black font-extrabold leading-[20px] block pr-4 pl-3 font-foobar md:text-[18px] lg:text-[22px] hover:text-white" aria-current="page">BERANDA</a>
                        </li>
                        <li class="flex items-center">
                            <a href="https://extrajoss.co.id/mekanisme" class="text-black font-extrabold leading-[20px] block pr-4 pl-3 font-foobar md:text-[18px] lg:text-[22px] ml-[80px] mr-[75px] hover:text-white" aria-current="page">MEKANISME</a>
                        </li>

                        <?php if(auth()->guard()->check()): ?>
                        <button id="dropdownHoverButton" data-dropdown-toggle="dropdownHover" data-dropdown-trigger="hover" class="text-whit bg-transparent  font-medium rounded-lg text-sm px-1 py-1 text-center hidden lg:inline-flex items-center ml-[5%]  " type="button"><img class="w-7 h-7 rounded-full" src="https://ui-avatars.com/api/?name=<?php echo e(Auth::user()->name); ?>" alt="Rounded avatar">
                            <span class="p-1">Hi kak, <?php echo e(Auth::user()->name); ?></span></button>
                        <!-- Dropdown menu -->
                        <div id="dropdownHover" class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
                            <ul class="py-2 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="dropdownHoverButton">
                                <li>
                                    <a href="" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white"> <span class="inline-block mb-[-5px] mr-[5px]">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user mr-1 align-bottom">
                                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                                <circle cx="12" cy="7" r="4"></circle>
                                            </svg>
                                        </span> Profil</a>
                                </li>
                                <li>
                                    <a href="" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white"> <span class="inline-block mb-[-5px] mr-[10px]">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="27" viewBox="0 0 28 27" fill="none" class="tw-text-black">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M8.71875 0.649902H19.1813C20.1443 0.649902 20.925 1.43061 20.925 2.39365V5.88115H26.1563C27.1193 5.88115 27.9 6.66186 27.9 7.6249V25.0624C27.9 26.0254 27.1193 26.8062 26.1563 26.8062H1.74375C0.780704 26.8062 0 26.0254 0 25.0624V7.6249C0 6.66186 0.780704 5.88115 1.74375 5.88115H6.975V2.39365C6.975 1.43061 7.7557 0.649902 8.71875 0.649902ZM8.71875 5.88115H19.1813V2.39365H8.71875V5.88115ZM19.1813 7.6249H8.71875H1.74375V25.0624H26.1563V7.6249H19.1813ZM3.80545 14.1701L9.14861 9.6866L12.5112 13.6939L11.0066 17.2329L7.16804 18.1775L3.80545 14.1701ZM7.80582 16.2248L9.74307 15.748L10.4881 13.9957L8.93367 12.1433L6.26209 14.3849L7.80582 16.2248ZM20.0531 21.5749C21.4977 21.5749 22.6688 20.4039 22.6688 18.9593C22.6688 17.5147 21.4977 16.3437 20.0531 16.3437C18.6085 16.3437 17.4375 17.5147 17.4375 18.9593C17.4375 20.4039 18.6085 21.5749 20.0531 21.5749Z" fill="currentColor"></path>
                                            </svg>
                                        </span> Pemesanan</a>
                                </li>

                                <li class="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <span class="inline-block mb-[-5px]"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-log-out mr-1 align-middle">
                                                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                                                <polyline points="16 17 21 12 16 7"></polyline>
                                                <line x1="21" y1="12" x2="9" y2="12"></line>
                                            </svg></span> Keluar
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </li>
                            </ul>
                        </div>

                        <?php endif; ?>

                        <?php if(auth()->guard()->guest()): ?>
                        <li class="relative">
                            <div class="kotak4 h-[36px] w-[250px]">
                            </div>
                            <div class="absolute top-[21px] left-[40px]">
                                <?php if(auth()->guard()->guest()): ?>
                                <a class="text-white leading-[20px]  pr-4 pl-3 font-foobar md:text-[18px] lg:text-[22px] cursor-pointer modal-login-button " aria-current="page">Masuk</a>
                                <span class="list-none font-foobar text-white text-[20px] mx-2">|</span>
                                <a class="text-white leading-[20px] inline  pr-4 pl-3 font-foobar md:text-[18px] lg:text-[22px] cursor-pointer modal-register-button" aria-current="page">Daftar</a>
                                <?php endif; ?>



                            </div>
                        </li>

                        <?php endif; ?>

                        <li class="flex items-center">
                            <a href="https://extrajoss.co.id/pemenang" class="text-[#FF0000] leading-[20px] block pr-4 pl-3 font-head md:text-[18px] lg:text-[22px]" aria-current="page"><img src="<?php echo e(asset('images/logoejaudax.png')); ?>" class="h-[50px]" alt=""></a>
                        </li>


                    </ul>
                </div>
            </div>
        </nav>

    </div>
</section>





<section class="px-4 pb-[80px] pt-4" style="background-image: url(/images/bg-main-section.jpg); background-repeat: no-repeat;
  background-size: cover;">
    <div class="container-lg">

        <div class="flex justify-center  mt-[59px] text-[50px] ">
            <h1 class="text-center w-[850px] text-[50px] font-foobar italic font-extrabold ">SPARTAN PARIS BREST PARIS RIDE FOR CHARITY</h1>
        </div>
        <div class="flex justify-center mt-[50px]">
            <h1 class="text-center w-[850px] text-[35px] font-foobar italic font-extrabold ">VOTE & SUPPORT RIDER</h1>
        </div>



        <div class="hidden lg:flex mt-40 mx-3 lg:mx-5 ">
            <div class="relative mb-[300px] lg:mb-0">
                <div class="kotak6 h-[250px] w-[260px] lg:h-[350px] lg:w-[330px]  bg-black ">
                </div>
                <div class="absolute top-[-70px] left-[100px] lg:left-[155px]">
                    <img src="<?php echo e(asset('images/munir.png')); ?>" alt="">
                </div>
                <h3 class="absolute top-[110px] left-[139px] text-[#E7EA03] text-[20px] lg:text-[30px] font-foobar font-black tracking-wider">
                    HANDIKA
                </h3>
                <p class="absolute top-[180px] left-[70px] text-white text-[27px] lg:text-[40px] font-DelaGothic font-bold">756 VOTES</p>
                <a href="" class=" absolute z-2 top-[300px] left-[40px] text-white text-[18px] lg:text-[25px] bg-[#E61E1E] py-2 px-3 shadow-2xl rounded-lg kotak3">PROGRAM PLAN</a>

                <a href="" class=" absolute top-[340px] left-[-3px] text-black text-[18px] lg:text-[30px] bg-[#E7EA03] font-foobar py-3 px-8 rounded-lg flex justify-between shadow-2xl kotak3">
                    <span>VOTE NOW</span>
                    <span><img src="<?php echo e(asset('images/top.png')); ?>" alt="" class="mt-[8px] ml-[17px]"></span></a>
            </div>
            <div class="relative mb-[300px] lg:mb-0">
                <div class="kotak6 h-[250px] w-[260px] lg:h-[350px] lg:w-[330px]  bg-black ">
                </div>
                <div class="absolute top-[-70px] left-[100px] lg:left-[155px]">
                    <img src="<?php echo e(asset('images/munir.png')); ?>" alt="">
                </div>
                <h3 class="absolute top-[110px] left-[139px] text-[#E7EA03] text-[20px] lg:text-[30px] font-foobar font-black tracking-wider">
                    MUNIR
                </h3>
                <p class="absolute top-[180px] left-[70px] text-white text-[27px] lg:text-[40px] font-DelaGothic font-bold">756 VOTES</p>
                <a href="" class=" absolute z-2 top-[300px] left-[40px] text-white text-[18px] lg:text-[25px] bg-[#E61E1E] py-2 px-3 shadow-2xl rounded-lg kotak3">PROGRAM PLAN</a>

                <a href="" class=" absolute top-[340px] left-[-3px] text-black text-[18px] lg:text-[30px] bg-[#E7EA03] font-foobar py-3 px-8 rounded-lg flex justify-between shadow-2xl kotak3">
                    <span>VOTE NOW</span>
                    <span><img src="<?php echo e(asset('images/top.png')); ?>" alt="" class="mt-[8px] ml-[17px]"></span></a>
            </div>
            <div class="relative mb-[300px] lg:mb-0">
                <div class="kotak6 h-[250px] w-[260px] lg:h-[350px] lg:w-[330px]  bg-black ">
                </div>
                <div class="absolute top-[-70px] left-[100px] lg:left-[155px]">
                    <img src="<?php echo e(asset('images/munir.png')); ?>" alt="">
                </div>
                <h3 class="absolute top-[110px] left-[139px] text-[#E7EA03] text-[20px] lg:text-[30px] font-foobar font-black tracking-wider">
                    LUCKYBW
                </h3>
                <p class="absolute top-[180px] left-[70px] text-white text-[27px] lg:text-[40px] font-DelaGothic font-bold">756 VOTES</p>
                <a href="" class=" absolute z-2 top-[300px] left-[40px] text-white text-[18px] lg:text-[25px] bg-[#E61E1E] py-2 px-3 shadow-2xl rounded-lg kotak3">PROGRAM PLAN</a>

                <a href="" class=" absolute top-[340px] left-[-3px] text-black text-[18px] lg:text-[30px] bg-[#E7EA03] font-foobar py-3 px-8 rounded-lg flex justify-between shadow-2xl kotak3">
                    <span>VOTE NOW</span>
                    <span><img src="<?php echo e(asset('images/top.png')); ?>" alt="" class="mt-[8px] ml-[17px]"></span></a>
            </div>

        </div>

        <div class="flex flex-wrap lg:hidden mt-40 mx-3 lg:mx-5 ">
            <div class="relative mb-[130px] lg:mb-0">
                <div class="kotak6 h-[250px] w-[260px] lg:h-[350px] lg:w-[330px]  bg-black ">
                </div>
                <div class="absolute top-[-70px] left-[100px] lg:left-[155px]">
                    <img src="<?php echo e(asset('images/munir.png')); ?>" alt="">
                </div>
                <h3 class="absolute top-[110px] left-[139px] text-[#E7EA03] text-[20px] lg:text-[30px] font-foobar font-black tracking-wider">
                    HANDIKA
                </h3>
                <p class="absolute top-[180px] left-[70px] text-white text-[27px] lg:text-[40px] font-DelaGothic font-bold">756 VOTES</p>
                <a href="" class=" absolute z-2 top-[300px] left-[40px] text-white text-[18px] lg:text-[25px] bg-[#E61E1E] py-2 px-3 shadow-2xl rounded-lg kotak3">PROGRAM PLAN</a>

                <a href="" class=" absolute top-[340px] left-[-3px] text-black text-[18px] lg:text-[30px] bg-[#E7EA03] font-foobar py-3 px-8 rounded-lg flex justify-between shadow-2xl kotak3">
                    <span>VOTE NOW</span>
                    <span><img src="<?php echo e(asset('images/top.png')); ?>" alt="" class="mt-[8px] ml-[17px]"></span></a>
            </div>
            <div class="relative mb-[130px] lg:mb-0">
                <div class="kotak6 h-[250px] w-[260px] lg:h-[350px] lg:w-[330px]  bg-black ">
                </div>
                <div class="absolute top-[-70px] left-[100px] lg:left-[155px]">
                    <img src="<?php echo e(asset('images/munir.png')); ?>" alt="">
                </div>
                <h3 class="absolute top-[110px] left-[139px] text-[#E7EA03] text-[20px] lg:text-[30px] font-foobar font-black tracking-wider">
                    MUNIR
                </h3>
                <p class="absolute top-[180px] left-[70px] text-white text-[27px] lg:text-[40px] font-DelaGothic font-bold">756 VOTES</p>
                <a href="" class=" absolute z-2 top-[300px] left-[40px] text-white text-[18px] lg:text-[25px] bg-[#E61E1E] py-2 px-3 shadow-2xl rounded-lg kotak3">PROGRAM PLAN</a>

                <a href="" class=" absolute top-[340px] left-[-3px] text-black text-[18px] lg:text-[30px] bg-[#E7EA03] font-foobar py-3 px-8 rounded-lg flex justify-between shadow-2xl kotak3">
                    <span>VOTE NOW</span>
                    <span><img src="<?php echo e(asset('images/top.png')); ?>" alt="" class="mt-[8px] ml-[17px]"></span></a>
            </div>
            <div class="relative mb-[130px] lg:mb-0">
                <div class="kotak6 h-[250px] w-[260px] lg:h-[350px] lg:w-[330px]  bg-black ">
                </div>
                <div class="absolute top-[-70px] left-[100px] lg:left-[155px]">
                    <img src="<?php echo e(asset('images/munir.png')); ?>" alt="">
                </div>
                <h3 class="absolute top-[110px] left-[139px] text-[#E7EA03] text-[20px] lg:text-[30px] font-foobar font-black tracking-wider">
                    LUCKYBW
                </h3>
                <p class="absolute top-[180px] left-[70px] text-white text-[27px] lg:text-[40px] font-DelaGothic font-bold">756 VOTES</p>
                <a href="" class=" absolute z-2 top-[300px] left-[40px] text-white text-[18px] lg:text-[25px] bg-[#E61E1E] py-2 px-3 shadow-2xl rounded-lg kotak3">PROGRAM PLAN</a>

                <a href="" class=" absolute top-[340px] left-[-3px] text-black text-[18px] lg:text-[30px] bg-[#E7EA03] font-foobar py-3 px-8 rounded-lg flex justify-between shadow-2xl kotak3">
                    <span>VOTE NOW</span>
                    <span><img src="<?php echo e(asset('images/top.png')); ?>" alt="" class="mt-[8px] ml-[17px]"></span></a>
            </div>

        </div>

        <div class="flex justify-center mt-[124px]">
            <p class=" text-center text-[18px] w-[952px] font-Montserrat">
                Setelah berhasil menaklukan tantangan memecahkan rekor Jakarta - Bali Dalam waktu 4 hari, kini para SPARTAN ingin menaklukan dunia dengan tantangan “Paris Brest Paris” Event Audax yang diselenggarakan di Paris ini mempunyai jarak tempuh 1200 km hampir sama memang dengan Jakarta - Bali hanya saja kini jalur yang harus mereka lalui tanpa support ideal dari siapapun, hanya bergantung pada diri sendiri.
            </p>
        </div>

        <div class="flex justify-center mt-10">
            <p class=" text-center text-[18px] w-[952px] font-Montserrat">
                Next level memang melekat dalam jiwa para SPARTAN, tanpa support sistem yang ideal mereka akan bahu membahu menaklukan “Paris Brest Paris” Tim yang akan berjuang pun berbeda dengan tim Jakarta - Bali, kini SPARTAN hanya akan diperkuat sang captain Handika dan si roda gila Munir, juga ada member baru bernama Lucky yang siap melengkapi persenjataan para SPARTAN. Dengan tantangan harus finish dibawah 70 jam.

            </p>
        </div>
        <div class="flex justify-center mt-3 mb-40">
            <p class=" text-center text-[18px] w-[952px] font-Montserrat">
                Inilah cerita mereka tanpa rasa takut dan rasa lelah mereka akan membuktikan dan membawa harum nama Indonesia dalam EJ Sport “ Everyone Can”.
            </p>
        </div>

        <div class="flex justify-center mt-3">
            <h1 class="text-center text-[50px] italic font-extrabold ">
                #EVERYONECAN
            </h1>

        </div>
    </div>
</section>




<section class="bg-[#F0F0F0] pt-[60px]">
    <div class="container-xl h-[1000px] bg-white pt-[100px] rounded-none lg:rounded-2xl w-[100%] lg:w-[70%]">
        <div class="flex justify-center mb-[30px]">
            <h1 class=" font-foobar text-[29px] text-center lg:text-start ">
                Kasih dukungan ke tim SPARTAN
            </h1>
        </div>

        <div class="px-2 py-4 bg-white  mx-auto max-w-2xl sm:px-5 hover:border-blue-200">

            <div class="relative">

                <div class="absolute inset-y-0 right-0 flex items-center pr-3.5 cursor-pointer post-comment">
                    <a>
                        <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 16">
                            <path d="m10.036 8.278 9.258-7.79A1.979 1.979 0 0 0 18 0H2A1.987 1.987 0 0 0 .641.541l9.395 7.737Z" />
                            <path d="M11.241 9.817c-.36.275-.801.425-1.255.427-.428 0-.845-.138-1.187-.395L0 2.6V14a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V2.5l-8.759 7.317Z" />
                        </svg>
                    </a>
                </div>
                <div class="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none">
                    <?php if(auth()->guard()->guest()): ?>
                    <img alt="profil" src="https://ui-avatars.com/api/?name=Anonymous" class="object-cover w-8 h-8 mx-auto rounded-full">
                    <?php endif; ?>
                    <?php if(auth()->guard()->check()): ?>
                    <img alt="profil" src="https://ui-avatars.com/api/?name=<?php echo e(Auth::user()->name); ?>" class="object-cover w-8 h-8 mx-auto rounded-full">
                    <?php endif; ?>
                </div>
                <input type="text" id="comment" name="comment" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-full focus:ring-blue-500 focus:border-blue-500 block w-[102%] h-16 pl-16 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="tulis dukungan mu disini">
            </div>

            <div class="my-4 ">
                <div class="flex justify-end">
                    <small class="text-base font-bold text-gray-700 ml-1 comment-count"><?php echo e($commentCount); ?> comments</small>
                </div>
                <div class="flex flex-col mt-4 comment-column h-[500px] overflow-y-auto">
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex flex-row mx-auto justify-between px-1 py-1 mb-[30px]">
                        <div class="flex mr-2">
                            <div class="items-center justify-center w-12 h-12 mx-auto">
                                <img alt="profil" src="https://ui-avatars.com/api/?name=<?php echo e($comment->user->name); ?>" class="object-cover w-12 h-12 mx-auto rounded-full">
                            </div>
                        </div>
                        <div class="flex-1 pl-1 w-[550px]">
                            <div class=" text-[20px] font-semibold text-gray-600"><?php echo e($comment->user->name); ?><span class="text-sm font-normal text-gray-500"> <?php echo e($comment->time); ?></span>
                            </div>
                            <div class="text-sm text-gray-600">
                                <?php echo e($comment->comments); ?>

                            </div>

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <div class="flex justify-center">
                    <a class=" block w-1/2  text-white bg-[#E61E1E]  focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mt-16 mb-10 text-center ">LOAD MORE</a>
                </div>

            </div>
        </div>

    </div>
</section>

<section style="background-image: url(/images/bg-footer.png); background-repeat: no-repeat;
  background-size: cover;" class=" h-[600px] pt-3">

</section>


<div id="authentication-modal" tabindex="-1" class="hidden fixed top-0 left-0 right-0 z-50 w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full justify-center items-center flex modal-login" aria-modal="true" role="dialog">
    <div class="relative w-full max-w-2xl max-h-full">
        <!-- Modal content -->
        <div class="relative bg-black  shadow dark:bg-gray-700">
            <button type="button" class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white modal-login-button-close" data-modal-hide="authentication-modal">
                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"></path>
                </svg>
                <span class="sr-only">Close modal</span>
            </button>
            <div class="px-6 pt-6 pb-14 lg:px-8">
                <h3 class="mb-4 text-[35px] tracking-widest text-white text-center dark:text-white font-extrabold ">LOGIN</h3>
                <form class="space-y-6" action="#">
                    <div>
                        <label for="email" class="block mb-2 text-sm font-medium text-white">Email/Username</label>
                        <input type="email" name="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="name@company.com" required="">
                    </div>
                    <div>
                        <label for="password" class="block mb-2 text-sm font-medium text-white ">Password</label>
                        <input type="password" name="password" id="password" placeholder="••••••••" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" required="">
                    </div>

                    <button type="submit" class="w-full text-white bg-[#E61E1E]  focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mb-10 text-center ">LOGIN</button>
                </form>

                <div class=" mt-10">
                    <a href="<?php echo e(route('sign.google')); ?>" class="flex items-center justify-center px-4 py-2 space-x-2 transition-colors duration-300 border border-gray-800 rounded-md group  focus:outline-none bg-white hover:bg-gray-200">
                        <span>
                            <svg class="fill-current w-4 h-4 mr-2" viewBox="0 0 533.5 544.3" xmlns="http://www.w3.org/2000/svg">
                                <path d="M533.5 278.4c0-18.5-1.5-37.1-4.7-55.3H272.1v104.8h147c-6.1 33.8-25.7 63.7-54.4 82.7v68h87.7c51.5-47.4 81.1-117.4 81.1-200.2z" fill="#4285f4"></path>
                                <path d="M272.1 544.3c73.4 0 135.3-24.1 180.4-65.7l-87.7-68c-24.4 16.6-55.9 26-92.6 26-71 0-131.2-47.9-152.8-112.3H28.9v70.1c46.2 91.9 140.3 149.9 243.2 149.9z" fill="#34a853"></path>
                                <path d="M119.3 324.3c-11.4-33.8-11.4-70.4 0-104.2V150H28.9c-38.6 76.9-38.6 167.5 0 244.4l90.4-70.1z" fill="#fbbc04"></path>
                                <path d="M272.1 107.7c38.8-.6 76.3 14 104.4 40.8l77.7-77.7C405 24.6 339.7-.8 272.1 0 169.2 0 75.1 58 28.9 150l90.4 70.1c21.5-64.5 81.8-112.4 152.8-112.4z" fill="#ea4335"></path>
                            </svg>
                        </span>
                        <span class="text-sm font-medium text-gray-800 group-hover:text-black">Google</span>
                    </a>
                </div>
            </div>
            <div class="px-6 pt-3 pb-1 lg:px-8 bg-white">
                <h3 class="mb-4 text-[14px] tracking-widest text-black text-center dark:text-white  ">Don’t have an account? <a href="" class="font-extrabold">REGISTER</a></h3>



            </div>


        </div>
    </div>
</div>

<div id="authentication-modal" tabindex="-1" class="hidden fixed top-0 left-0 right-0 z-50 w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full justify-center items-center flex modal-register" aria-modal="true" role="dialog">
    <div class="relative w-full max-w-2xl max-h-full">
        <!-- Modal content -->
        <div class="relative bg-black  shadow dark:bg-gray-700">
            <button type="button" class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white modal-login-register-close" data-modal-hide="authentication-modal">
                <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"></path>
                </svg>
                <span class="sr-only">Close modal</span>
            </button>
            <div class="px-6 pt-6 pb-14 lg:px-8">
                <h3 class="mb-4 text-[35px] tracking-widest text-white text-center dark:text-white font-extrabold ">DAFTAR</h3>
                <form class="space-y-6" action="<?php echo e(route('daftar.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label for="name" class="block mb-2 text-sm font-medium text-white">Your Name</label>
                        <input type="text" name="name" id="name" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="name@company.com" required="">
                    </div>
                    <div class="grid md:grid-cols-2 md:gap-6">
                        <div class="relative z-0 w-full mb-2 group">
                            <label for="email" class="block mb-2 text-sm font-medium text-white">Email</label>
                            <input type="email" name="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="name@company.com" required="">
                        </div>
                        <div class="relative z-0 w-full mb-2 group">
                            <label for="phone" class="block mb-2 text-sm font-medium text-white">Phone Number</label>
                            <input type="number" name="phone" id="phone" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="0821xxxxxxx" required="">
                        </div>
                    </div>
                    <div>
                        <label for="password" class="block mb-2 text-sm font-medium text-white ">Password</label>
                        <input type="password" name="password" id="password" placeholder="••••••••" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" required="">
                    </div>

                    <button type="submit" class="w-full text-white bg-[#E61E1E]  focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mb-10 text-center ">DAFTAR</button>
                </form>
            </div>
            <div class="px-6 pt-3 pb-1 lg:px-8 bg-white">
                <h3 class="mb-4 text-[14px] tracking-widest text-black text-center dark:text-white  ">Already have an account? <a href="" class="font-extrabold">LOGIN</a></h3>

            </div>


        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript-internal'); ?>

<script>
    $(document).ready(function() {


        let base_url = window.location.origin;
        $(window).on('beforeunload', function() {
            $(window).scrollTop(0);
        });


        $('.modal-login-button').on('click', function() {
            $('.modal-login').removeClass('hidden')
        })
        $('.modal-login-button-close').on('click', function() {
            $('.modal-login').addClass('hidden')
        })

        $('.modal-register-button').on('click', function() {
            $('.modal-register').removeClass('hidden')
        })
        $('.modal-login-register-close').on('click', function() {
            $('.modal-register').addClass('hidden')
        })



        $(document).scroll(function() {
            var scroll = $(this).scrollTop();
            var topDist = $("#banner-header").position();
            if (scroll > topDist.top) {
                $('.navbar-top').removeClass('bg-transparent')
                $('.navbar-top').addClass('bg-[#9294A3]')

            } else {
                $('.navbar-top').removeClass('bg-[#9294A3]')
                $('.navbar-top').addClass('bg-transparent')
            }
        });

        $('.post-comment').on('click', function(e) {
            let comment = $('#comment').val()


            if (comment == '') {

                return alert('silahkan isi')
            }

            $.ajax({
                type: "POST",
                url: `${base_url}/comment`,
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                        "content"
                    ),
                },
                data: {
                    comment,
                },
                error: function(xhr, error) {
                    if (xhr.status === 500) {
                        console.log(error);

                        $(e.target).html("Gagal Terkirim");

                        setTimeout(() => {
                            location.reload();
                        }, 2500);
                    }
                },
                success: function(data) {
                    let comments = data;
                    $('.comment-count').empty()
                    $('.comment-count').append(data[0] + ' comment')
                    $('.comment-column').empty()

                    for (i = 0; i < comments[1].length; i++) {
                        $('.comment-column').append(`<div class="flex flex-row mx-auto justify-between px-1 py-1 mb-[30px]">
                        <div class="flex mr-2">
                            <div class="items-center justify-center w-12 h-12 mx-auto">
                                <img alt="profil" src=https://ui-avatars.com/api/?name=${data[1][i]['user'].name}" class="object-cover w-12 h-12 mx-auto rounded-full">
                            </div>
                        </div>
                        <div class="flex-1 pl-1 w-[550px]">
                            <div class=" text-[20px] font-semibold text-gray-600">${data[1][i]['user'].name}<span class="text-sm font-normal text-gray-500"> ${comments[1][i].time}</span>
                            </div>
                            <div class="text-sm text-gray-600">
                               ${comments[1][i].comments}
                            </div>

                        </div>
                    </div>`)
                    }
                },
            });
        })


    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('web.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\extrajoss-vote-app\resources\views/web/homepage/index.blade.php ENDPATH**/ ?>