
<?php $__env->startSection('title'); ?>
<?php
$postId = last(request()->segments());
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Basic Bootstrap Table -->
<div class="card">
    <div class="d-flex justify-content-between">

        <h5 class="card-header">User</h5>
       
    </div>
    <div class="table-responsive text-nowrap" style="height:1000px">
        <table class="table">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Name</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody class="table-border-bottom-0">
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($loop->iteration); ?>

                    </td>
                    <td><strong><?php echo e($row->name); ?></strong></td>
                    <td><?php echo e($row->email); ?></td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>


</div>
<div class="col-lg-4 col-md-6">
    <small class="text-light fw-semibold">Vertically centered</small>
    <div class="mt-3">
        <!-- Button trigger modal -->


        <!-- Modal -->
        <div class="modal fade" id="modalCenter" tabindex="-1" aria-hidden="true" style="display: none;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <form action="<?php echo e(route('riders.store')); ?>" method="post">


                    <?php echo csrf_field(); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalCenterTitle">Vote Popup</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="mb-3">
                                    <label for="exampleFormControlSelect1" class="form-label">Select Rider</label>
                                    <select class="form-select" id="exampleFormControlSelect1" aria-label="Default select example" fdprocessedid="m9ri69" name="riders">
                                        <option selected="">Open this select menu</option>
                                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                <div class="col mb-3">
                                    <label for="nameWithTitle" class="form-label">Vote</label>
                                    <input type="number" id="nameWithTitle" class="form-control" placeholder="Vote" style="width: 500px;" name="vote">
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </div>
            </div>
            </form>
        </div>
    </div>
</div>

<!--/ Basic Bootstrap Table -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('javascript-internal'); ?>
<script>
    $(document).ready(function() {

        $('.exit').on('click', function() {
            $('#modalCenter').removeClass('show')
        })

        $('.showModal').on('click', function() {
            $('#modalCenter').addClass('show')
        })


        // event delete category
        $("form[role='alert']").submit(function(event) {
            event.preventDefault();
            Swal.fire({
                title: "Apakah anda ingin menghapus ?",
                text: $(this).attr('alert-text'),
                icon: 'warning',
                allowOutsideClick: false,
                showCancelButton: true,
                cancelButtonText: "Cancel",
                reverseButtons: true,
                confirmButtonText: "Yes",
            }).then((result) => {
                if (result.isConfirmed) {
                    // todo: process of deleting categories
                    event.target.submit();
                }
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('javascript-external'); ?>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('javascript-internal'); ?>
<script>
    $(document).ready(function() {
        var table = $('.data-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: "",
            columns: [
                //{data: 'DT_RowIndex', name: 'DT_RowIndex'},
                //  { "width": "20%" },
                {
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: false,
                    searchable: false
                },
                {
                    data: 'name',
                    name: 'name'
                },
                //  {
                //      data: 'email',
                //      name: 'email'
                //  },
                {
                    data: 'roles',
                    name: 'roles'
                },
                {
                    data: 'action',
                    name: 'action'
                },
                //  {
                //      data: 'finish_date',
                //      name: 'finish_date'
                //  },
                // {
                //    data: 'created_at',
                //    render: function(d) {
                //       return moment(d).format("DD/MM/YYYY HH:mm");
                //    }
                // },
                // {
                //    data: 'email',
                //    name: 'subject'
                // },
                // {
                //    data: 'email',
                //    name: 'address'
                // },
                // {
                //    data: 'email',
                //    name: 'phone'
                // },
                // {
                //    data: 'email',
                //    name: 'message'
                // }

            ]
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\extrajoss-vote-app\resources\views/admin/users/index.blade.php ENDPATH**/ ?>