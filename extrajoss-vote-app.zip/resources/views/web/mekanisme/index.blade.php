@extends('web.index')

@section('container')


<header>
    <nav class="fixed  z-30 w-100 top-0 left-0 bg-[#9294A3] px-10 sm:px-6 py-4 xl:px-[70px] lg:pt-[25px] h-[100px]">
        <div class="container flex flex-wrap justify-between items-center mx-auto">
            <a href="" class="flex items-center">
                <img src="{{ asset('images/logo.png') }}" class="absolute top-[8px] mr-3 h-[70px] lg:h-[83px] sm:h-[150px]" alt="Extrajoss Logo">
            </a>

            <li class="lg:hidden flex items-center ml-[30%]">
                <a href="https://extrajoss.co.id/pemenang" class="text-[#FF0000] leading-[20px] block pr-4 pl-3 font-head md:text-[18px] lg:text-[22px]" aria-current="page"><img src="{{ asset('images/logoejaudax.png') }}" class="h-[50px]" alt=""></a>
            </li>


            <a href="" class="lg:hidden">
                <div class="space-y-2">
                    <span class="block w-8 h-0.5 bg-gray-600"></span>
                    <span class="block w-8 h-0.5 bg-gray-600"></span>
                    <span class="block w-5 h-0.5 bg-gray-600"></span>
                </div>
            </a>



            <div class=" hidden lg:block w-full md:block md:w-auto pb-8" id="navbar-default">
                <ul class=" flex flex-col px- md:flex-row md:space-x-2 lg:space-x-4 md:mt-0 ">
                    <li class="flex items-center">
                        <a href="https://extrajoss.co.id" class="text-black font-extrabold leading-[20px] block pr-4 pl-3 font-foobar md:text-[18px] lg:text-[22px] hover:text-white" aria-current="page">BERANDA</a>
                    </li>
                    <li class="flex items-center">
                        <a href="https://extrajoss.co.id/mekanisme" class="text-black font-extrabold leading-[20px] block pr-4 pl-3 font-foobar md:text-[18px] lg:text-[22px] ml-[80px] mr-[75px] hover:text-white" aria-current="page">MEKANISME</a>
                    </li>


                    <li class="relative">
                        <div class="kotak4 h-[36px] w-[250px]">
                        </div>
                        <div class="absolute top-[21px] left-[40px]">
                            <a href="https://extrajoss.co.id/pemenang" class="text-white leading-[20px]  pr-4 pl-3 font-foobar md:text-[18px] lg:text-[22px] " aria-current="page">Masuk</a>
                            <span class="list-none font-foobar text-white text-[20px] mx-2">|</span>
                            <a href="https://extrajoss.co.id/pemenang" class="text-white leading-[20px] inline  pr-4 pl-3 font-foobar md:text-[18px] lg:text-[22px]" aria-current="page">Daftar</a>
                        </div>
                    </li>

                    <li class="flex items-center">
                        <a href="https://extrajoss.co.id/pemenang" class="text-[#FF0000] leading-[20px] block pr-4 pl-3 font-head md:text-[18px] lg:text-[22px]" aria-current="page"><img src="{{ asset('images/logoejaudax.png') }}" class="h-[50px]" alt=""></a>
                    </li>


                </ul>
            </div>
        </div>
    </nav>
</header>

<section class="relative overflow-hidden">
    <div class="absolute h-[300px] w-[300px] bg-red-300 z-50">
        <h1>TEs</h1>
    </div>
</section>


<section style="background-image: url(/images/bg-footer.png); background-repeat: no-repeat;
  background-size: cover;" class="hidden lg:block h-[100vh] pt-3">
    <div class="container-xl">

        <div class="flex justify-center font-foobar text-[40px] mt-[150px] mb-[44px] font-extrabold">
            <h1>MEKANISME VOTING</h1>
        </div>
        <div class="py-3 px-[80px] text-[18px] text-black">
            <ul class="list-decimal px-4">
                <li class="mb-3">Vote adalah bentuk dukungan terhadap program masing-masing Spartan</li>
                <li class="mb-3">Jumlah Vote adalah Jumlah produk SKU yang terjual</li>
                <li class="mb-3">Jumlah vote di update secara manual dengan metode jumlah produk yang terlihat di update per jam (9.00, 14.00, 20.00)</li>
                <li class="mb-3">1 Akun bisa melakukan Vote berkali-kali (tidak di kunci) karena yang di hitung adalah jumlah produk yang terjual</li>
            </ul>
        </div>
    </div>
</section>


<section style="background-image: url(/images/bg-mekanisme-mobile.jpg); background-repeat: no-repeat;
  background-size: cover;" class=" h-[1280px] pt-3 block lg:hidden">
    <div class="container-xl">

        <div class="flex justify-center font-foobar text-[25px] lg:text-[40px] mt-[150px] mb-[44px] font-extrabold">
            <h1>MEKANISME VOTING</h1>
        </div>
        <div class="py-3 px-[50px] text-[18px] text-black">
            <ul class="list-decimal px-4">
                <li class="mb-3">Vote adalah bentuk dukungan terhadap program masing-masing Spartan</li>
                <li class="mb-3">Jumlah Vote adalah Jumlah produk SKU yang terjual</li>
                <li class="mb-3">Jumlah vote di update secara manual dengan metode jumlah produk yang terlihat di update per jam (9.00, 14.00, 20.00)</li>
                <li class="mb-3">1 Akun bisa melakukan Vote berkali-kali (tidak di kunci) karena yang di hitung adalah jumlah produk yang terjual</li>
            </ul>
        </div>
    </div>
</section>







</div>
@endsection

@push('javascript-internal')
<script src="https://cdnjs.cloudflare.com/ajax/libs/instafeed.js/1.4.1/instafeed.min.js" integrity="sha512-7vRrNQ5TnkhihLzA4Qd32yZP5A1oZvqmowU5OxgL612vmfd1eLgfgvB31J6Wdg8/tQqvikZdrNsZAj0WeONL/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $(document).ready(function() {

        let base_url = window.location.origin;
        let $flatpicker = $(".selector").flatpickr({
            dateFormat: "d/m/Y",
            minDate: "today",
            maxDate: "31.12.2029",
            altInput: true,
            mode: "range",
            onChange: function(selectedDates, datestr, instance) {


                // $(".selector").val(selectedDates[0] + ' - ' + this.formatDate(selectedDates[0], "j F Y"));
                $(".selector").val(datestr.replace('to', '-'));
            }
        });

        $('.reset-filter').on('click', function() {
            $("select option:first-child").attr("selected", "selected");
            $flatpicker.clear()



            $.ajax({
                type: "POST",
                url: `${base_url}/resetFilter`,
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                        "content"
                    ),
                },
                data: {
                    id: 6,
                },
                error: function(xhr, error) {
                    if (xhr.status === 500) {
                        console.log(error);

                        $(e.target).html("Gagal Terkirim");

                        setTimeout(() => {
                            location.reload();
                        }, 2500);
                    }
                },
                success: function(data) {

                    $('.result-text').addClass('hidden')
                    $('.reset-filter').addClass('hidden')
                    $('.home-section').empty()
                    let result = data.result
                    if (result.length === 0) {

                        $('.home-section').append(
                            `<div class=" w-full flex justify-start text-[20px] text-greyDetTbliss ml-[15px]">
                            Maaf Kak, tidak ada jadwal trip pada saat ini
                            </div>`
                        )
                    } else {

                        result.forEach(function(item, index) {
                            $('.home-section').append(
                                `
                                    <div class="basis-full lg:basis-4/12 px-3 pt-[50px] pb-3 hover:drop-shadow-md hover:cursor-pointer ">
                                        <div class="max-w-sm bg-white ">
                                            <a href="/countries/korea/detail/${item.slug}">
                                                <img src="${item.thumbnail}" alt="" class="w-full">
                                            </a>
                                            <div class="mt-3 flex flex-col ">
                                                <div class="flex  flex-1 ">
                                                    <h5 class="text-blueTbliss mr-3 text-[12px] pl-[15px]">
                                                        ${item.seat} seats left
                                                    </h5>
                                                    <img src="{{ asset('images/trip/seat.png') }}" alt="" class="inline  h-[12px]">
                                                </div>
                                                <a href="/countries/korea/detail/${item.slug}">
                                                    <h5 class="mb-2 text-2xl font-bold tracking-[1px] font-bely text-greyTbliss text-[24px] h-[130px] px-[15px]">${item.title}</h5>
                                                </a>
                                                <div class="flex-1 px-[15px]">
                            <span class="text-[#6A6A6A] font-interRegular font-bold text-[22px] mr-5">
                            ${item.day}H${item.night}M
                            </span>
                            <span>
                                |
                            </span>
                            <span class="ml-3 text-[16px]">
                            ${item.date_from_result} - ${item.date_to_result}

                            </span>
                        </div>
                        <p class="text-redTbliss font-bold text-[19px] flex-1 px-[15px] pb-[20px]">
                        ${item.price.toLocaleString("id-ID", {style:"currency", currency:"IDR",minimumFractionDigits: 0})}
                        </p>
                                                
                                            </div>
                                        </div>
                                    </div>
                                `
                            )

                        })
                    }
                },
            });
        })

        $('#searchTrips').on('click', function(e) {
            let id = $('#countries').val()
            let dates = $('.selector').val()
            let dateFrom = dates.slice(0, 10)
            let dateTo = dates.slice(13, 23)
            let seats = $('#seats').val()


            $.ajax({
                type: "POST",
                url: `${base_url}/seacrhByDate`,
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                        "content"
                    ),
                },
                data: {
                    id,
                    dateFrom,
                    dateTo,
                    seats
                },
                error: function(xhr, error) {
                    if (xhr.status === 500) {
                        console.log(error);

                        $(e.target).html("Gagal Terkirim");

                        setTimeout(() => {
                            location.reload();
                        }, 2500);
                    }
                },
                success: function(data) {
                    $('html, body').animate({
                        scrollTop: $('#hometrip').offset().top - 128
                    }, 500, 'swing');
                    $('.result-text').removeClass('hidden')
                    $('.reset-filter').removeClass('hidden')
                    $('.home-section').empty()
                    let result = data.result
                    if (result.length === 0) {
                        $('.result-text').text(
                            `Trip yang tersedia pada tanggal ${data.dateReqFrom} - ${data.dateReqTo}`
                        )
                        $('.home-section').append(
                            `<div class=" w-full flex justify-start text-[20px] text-greyDetTbliss ml-[15px]">
                            Maaf Kak, tidak ada jadwal trip pada saat ini
                            </div>`
                        )
                    } else {
                        $('.result-text').text(
                            `Trip yang tersedia pada tanggal ${data.dateReqFrom} - ${data.dateReqTo}`
                        )
                        result.forEach(function(item, index) {
                            $('.home-section').append(
                                `
                                    <div class="basis-full lg:basis-4/12 px-3 pt-[50px] pb-3 hover:drop-shadow-md hover:cursor-pointer ">
                                        <div class="max-w-sm bg-white ">
                                            <a href="/countries/korea/detail/${item.slug}">
                                                <img src="${item.thumbnail}" alt="" class="w-full">
                                            </a>
                                            <div class="mt-3 flex flex-col ">
                                                <div class="flex  flex-1 ">
                                                    <h5 class="text-blueTbliss mr-3 text-[12px] pl-[15px]">
                                                        ${item.seat} seats left
                                                    </h5>
                                                    <img src="{{ asset('images/trip/seat.png') }}" alt="" class="inline  h-[12px]">
                                                </div>
                                                <a href="/countries/korea/detail/${item.slug}">
                                                    <h5 class="mb-2 text-2xl font-bold tracking-[1px] font-bely text-greyTbliss text-[24px] h-[130px] px-[15px]">${item.title}</h5>
                                                </a>
                                                <div class="flex-1 px-[15px]">
                            <span class="text-[#6A6A6A] font-interRegular font-bold text-[22px] mr-5">
                            ${item.day}H${item.night}M
                            </span>
                            <span>
                                |
                            </span>
                            <span class="ml-3 text-[16px]">
                            ${item.date_from_result} - ${item.date_to_result}

                            </span>
                        </div>
                        <p class="text-redTbliss font-bold text-[19px] flex-1 px-[15px] pb-[20px]">
                        ${item.price.toLocaleString("id-ID", {style:"currency", currency:"IDR",minimumFractionDigits: 0})}
                        </p>
                                                
                                            </div>
                                        </div>
                                    </div>
                                `
                            )

                        })
                    }
                },
            });


        })

        $('.slider-for').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            // fade: true,
            asNavFor: '.testimoni-slider'
        });

        $('.slider-for').not('.slick-initialized').slick();


        $('.banner-slider').slick({
            dots: false,
            infinite: true,
            slidesToShow: 1,
            autoplay: false,
            // autoplaySpeed: 2000,
        });
        $('.banner-slider').not('.slick-initialized').slick();

        $('.testimoni-slider').slick({
            dots: false,
            infinite: true,
            slidesToShow: 1,
            autoplay: false,
            asNavFor: '.slider-for',
            arrows: true,
            prevArrow: '.left-testimoni-arrow',
            nextArrow: '.right-testimoni-arrow',
        });
        $('.testimoni-slider').not('.slick-initialized').slick();

        const options = {
            mobileFirst: true,
            responsive: [{
                breakpoint: 450,
                settings: "unslick"
            }]
        };

        var slicky = $('.hg-slider');
        slicky.slick(options);

        $(window).resize(function() {

            setTimeout(function() {

                if ($(window).width() < 450 && !slicky.hasClass("slick-initialized")) {
                    slicky.slick(options);
                }
            }, 100);
        });
        // $('.hg-slider').not('.slick-initialized').slick();

        // $('.dropdown-cls').each(function() {
        //     $(this).on('click', function(e) {
        //         let dataDropdown = $(this).data("drop")
        //         $('.dropdownMenu').toggleClass('hidden')
        //         $('.dropdownMenu').removeClass('hidden')

        //         $('.dropdownMenu').toggleClass('opacity-5')
        //         $('.dropdownMenu').toggleClass('hide')
        //         $('.search-box').toggleClass('active') 
        //         $(this).toggleClass('active')
        //         $(this).siblings().removeClass('active')
        //         $('.dropMenu').each(function(){
        //             let menu = $(this).data('menu')
        //             console.log(menu)
        //             if($(this).data('menu')===dataDropdown){
        //                 // alert($(this).data('menu') )
        //                 alert(`You clicked me. ${dataDropdown}`);
        //                 // $(this).toggleClass('hidden')
        //                 // $(this).siblings().removeClass('hidden')
        //                 // $(this).removeClass('hidden')
        //             }
        //         })
        //     })
        // })

        // $('.dropMenu').click(function(e){
        //     if(!$(e.target).closest('.dropdownMenu').length){
        //         console.log(e)
        //     }
        // })



    });
</script>
@endpush