<?php

namespace App\Http\Controllers;

use App\Models\Comments;
use App\Models\User;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {

        $commentCount = Comments::all()->count();



        $users = User::orderBy('created_at', 'DESC')->get();
        $userCount = $users->count();
        return view('home', compact('users', 'commentCount', 'userCount'));
    }
}
